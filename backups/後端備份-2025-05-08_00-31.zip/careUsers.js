exports.careUsers = [
  {
    "username": "pt001",
    "password": "0000",
    "name": "阿極"
  },
  {
    "username": "0000",
    "password": "0000",
    "name": "測試帳號"
  }
]
