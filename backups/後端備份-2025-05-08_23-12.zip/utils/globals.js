// utils/globals.js
global.activeTokens = {}
