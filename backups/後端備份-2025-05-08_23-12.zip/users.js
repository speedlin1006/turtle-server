exports.users = [
  {
    "username": "pt001",
    "password": "0000",
    "name": "阿極"
  },
  {
    "originalUsername": "0000",
    "username": "0000",
    "password": "0000",
    "name": "測試帳號"
  }
]
